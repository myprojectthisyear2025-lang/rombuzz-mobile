// src/socket.js
import { io } from "socket.io-client";
import { SOCKET_URL } from "./config";

// Track currently active chat peer
window.__activeChatId = null;
window.addEventListener("chat:active", (e) => {
  window.__activeChatId = e.detail.peerId;
});
window.addEventListener("chat:inactive", () => {
  window.__activeChatId = null;
});

// Single socket instance (reused everywhere)
let socket = null;


// Get token from localStorage
function getToken() {
  return localStorage.getItem("token") || "";
}

// Get user from localStorage
function getUser() {
  try {
    const stored = localStorage.getItem("user");
    return stored ? JSON.parse(stored) : null;
  } catch {
    return null;
  }
}


/**
 * Ensure one authenticated socket connection for the whole app.
 * Safe to call many times; it reuses the same instance.
 */
export function ensureSocketAuth() {
  const token = getToken();
if (!token) {
  console.warn("⚠️ No auth token found — socket connection skipped");
  return null;
}

  if (!socket) {
    socket = io(SOCKET_URL, {
      auth: { token },
      transports: ["websocket"],
       withCredentials: true,
      autoConnect: true,
      reconnection: true,
      reconnectionAttempts: 9999,
      reconnectionDelay: 1000,
    });
    console.log("🛰️ SOCKET connecting to:", SOCKET_URL);


    // Optional (your server supports both auth + register)
   // ✅ Identify user on connect (for Meet-in-Middle + chat)
socket.on("connect", () => {
  const u = getUser();
  if (u?.id || u?._id) {
    socket.emit("user:register", u.id || u._id);
    console.log("🧠 user:register sent for", u.id || u._id);
  }
});


    // Debug + global handlers
    socket.on("connect_error", (e) =>
      console.warn("SOCKET connect_error:", e?.message)
    );
    socket.on("disconnect", (r) => console.log("SOCKET disconnected:", r));

    // ✅ Global real-time notifications listener
    socket.on("notification", (notif) => {
      console.log("🔔 Global notification received:", notif);

      // --- optional: cache for later ---
      try {
        const key = "RBZ:pending:notifications";
        const existing = JSON.parse(localStorage.getItem(key) || "[]");
        existing.unshift(notif);
        localStorage.setItem(key, JSON.stringify(existing));
      } catch {}

      // --- dispatch a DOM event so any page (Navbar, Notifications.jsx) can react ---
      window.dispatchEvent(new CustomEvent("notification:new", { detail: notif }));
    });
// ✅ Real-time comments listener
socket.on("comment:new", (payload) => {
  console.log("💬 comment:new received:", payload);
  // broadcast globally so any open CommentsDrawer can update instantly
  window.dispatchEvent(new CustomEvent("comment:new", { detail: payload }));
});

    // 💞 Meet-in-Middle realtime handlers
    socket.on("meet:request", ({ from }) => {
      console.log("📍 meet:request from", from);
      window.dispatchEvent(new CustomEvent("meet:request", { detail: from }));
    });
    socket.on("meet:accept", (data) => {
      console.log("📍 meet:accept", data);
      window.dispatchEvent(new CustomEvent("meet:accept", { detail: data }));
    });
    socket.on("meet:suggest", (data) => {
      console.log("📍 meet:suggest places", data);
      window.dispatchEvent(new CustomEvent("meet:suggest", { detail: data }));
    });
    socket.on("meet:place:selected", (data) => {
      console.log("📍 meet:place:selected", data);
      window.dispatchEvent(new CustomEvent("meet:place:selected", { detail: data }));
    });

       // ✅ NEW: direct message event (patched for unread auto-clear)
    socket.on("direct:message", (msg) => {
      console.log("💬 direct:message received:", msg);

      // 🧠 If user is actively chatting with this peer → do NOT increment unread
      if (window.__activeChatId && (msg.fromId === window.__activeChatId || msg.from === window.__activeChatId)) {
        return window.dispatchEvent(
          new CustomEvent("direct:message", { detail: msg })
        );
      }

      // 🔔 Otherwise broadcast normally so unread count increases
      window.dispatchEvent(new CustomEvent("direct:message", { detail: msg }));

      // --- optional: sound or vibration (if enabled) ---
      try {
        const play = localStorage.getItem("RBZ:GLOBAL:msgSound");
        if (play === "true") {
          const ding = new Audio("data:audio/mp3;base64,//uQZAAAAAAAAAAAA");
          ding.play().catch(() => {});
        }
      } catch {}
    });

        // 💞 Match event → trigger global RomBuzz celebration
   socket.on("match", (payload) => {
  console.log("💞 match event received:", payload);

  // 💫 Play RomBuzz ding sound
  try {
    const audio = new Audio("https://assets.mixkit.co/sfx/preview/mixkit-achievement-bell-600.mp3");
    audio.volume = 0.7;
    audio.play().catch(() => {});
  } catch {}

  try {
    window.dispatchEvent(
      new CustomEvent("match:celebrate", { detail: payload })
    );
  } catch (e) {
    console.error("match:celebrate dispatch failed:", e);
  }
});



      // ✅ Optional badge reset listener
    window.addEventListener("notifications:clear", () => {
      window.dispatchEvent(new CustomEvent("notification:clearBadge"));
    });

       // =======================================================
    // 📞 LIVE CALL EVENTS (voice / video)
    // =======================================================
    socket.on("call:offer", (data) => {
      console.log("📞 call:offer", data);
      window.dispatchEvent(new CustomEvent("call:offer", { detail: data }));
    });

    socket.on("call:answer", (data) => {
      console.log("📞 call:answer", data);
      window.dispatchEvent(new CustomEvent("call:answer", { detail: data }));
    });

    socket.on("call:signal", (data) => {
      console.log("📡 call:signal", data);
      window.dispatchEvent(new CustomEvent("call:signal", { detail: data }));
    });

    socket.on("call:end", (data) => {
      console.log("📞 call:end", data);
      window.dispatchEvent(new CustomEvent("call:end", { detail: data }));
    });


  } else {
    // If token changed (login/logout), update and reconnect
    if (socket.auth?.token !== token) {
      socket.auth = { token };
      try {
        socket.disconnect();
      } catch {}
      socket.connect();
    }
  }

  return socket;
}

export function getSocket() {
  return socket || ensureSocketAuth();
}
