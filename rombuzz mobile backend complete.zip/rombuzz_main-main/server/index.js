// =====================================================
// ðŸ’— ROMBUZZ MAIN BACKEND ENTRY
// =====================================================
// Central API entry point for RomBuzz backend
// Handles all routes, middleware, and sockets.
// =====================================================

require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const http = require('http');
const shortid = require('shortid');
const sgMail = require('./config/sendgrid');
const upload = multer({ dest: 'uploads/' }); // âœ… used for avatar uploads fallback

// =======================
// ðŸªµ LOGGER (modularized)
// =======================
const { logInfo, logSuccess, logWarn, logError, logSocket } = require('./modules/logger');

// =======================
// âš™ï¸ GLOBAL CONFIG (Google + Feature Toggles)
// =======================
const { googleClient, FEATURE_TOGGLES } = require('./config/config');

// =======================
// ðŸŒ ENVIRONMENT CONFIG (centralized)
// =======================
const {
  PORT,
  JWT_SECRET,
  TOKEN_EXPIRES_IN,
  ADMIN_EMAIL,
  OBFUSCATION_MIN_METERS,
  OBFUSCATION_MAX_METERS,
  SHOW_PRIVATE,
  SHOW_RESTRICTED,
} = require('./config/env');

// âœ… ESM-safe fetch wrapper
const fetch = (...args) =>
  import('node-fetch').then(({ default: fetch }) => fetch(...args));

// =======================
// ðŸ” JWT HELPER (modularized)
// =======================
const { signToken } = require('./utils/jwt');

// =======================
// ðŸ“¦ DATABASE (modularized) â€” LowDB (legacy) + MongoDB init
// =======================
// ðŸ“¦ DATABASE (modularized) â€” LowDB (legacy) + MongoDB init + User sync
const db = require("./models/db.lowdb");
require("./models/writeGuard")(db);
const { initMongo } = require("./config/db");  // â­ REAL Mongo connection

// ðŸ”„ Optional one-time user sync on startup
const { bulkSyncAllUsers } = require("./modules/userSync");
(async () => {
  try {
    await db.read();
    if (db.data?.users?.length) {
      await bulkSyncAllUsers(db.data.users);
    } else {
      console.log("âš™ï¸  No users found in LowDB for sync");
    }
  } catch (err) {
    console.error("User bulk sync error:", err);
  }
})();

// =======================
// â˜ï¸ CLOUDINARY CONFIG (modularized)
// =======================
const cloudinary = require('./config/cloudinary');

// =======================
// ðŸ’« VIBE UTILITIES (modularized)
// =======================
const {
  PUBLIC_VIBES,
  PRIVATE_VIBES,
  RESTRICTED_VIBES,
  isAllowedVibeKey,
  isRestricted,
  hasPremium,
  isAgeVerified,
  canUseRestricted,
} = require('./utils/vibes');

// =======================
// ðŸ§© HELPER FUNCTIONS (modularized)
// =======================
const {
  baseSanitizeUser,
  isBlocked,
  msToDays,
  distanceKm,
  getRoomDoc,
  incMatchStreakOut,
  THIRTY_DAYS,
} = require('./utils/helpers');

// =======================
// ðŸ”” NOTIFICATION HELPERS (modularized)
// =======================
const { sendNotification, createNotification } = require('./utils/notifications');

// =======================
// ðŸ”’ SECURITY & CORS CONFIG (modularized)
// =======================
const setupCors = require('./config/cors');
const { setupSecurity } = require('./config/security');

// =======================
// âš¡ SOCKET.IO SETUP (modularized)
// =======================
const { setupSocket } = require('./config/socket');
const { buzzLocks, onlineUsers } = require('./models/state');

// =======================
// ðŸ§  SOCKET CONNECTION HANDLER
// =======================
const { registerConnection } = require('./sockets/connection');

// =======================
// ðŸš€ EXPRESS APP INITIALIZATION
// =======================
const app = express();
const server = http.createServer(app);

// Middleware
setupCors(app);
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));
setupSecurity(app);

// ðŸ”“ Root health route for Render & uptime checks
app.get("/", (req, res) => {
  res.status(200).json({
    status: "ok",
    message: "RomBuzz backend is running",
    timestamp: new Date().toISOString(),
  });
});

// Socket.IO
const io = setupSocket(server);
global.io = io;
global.onlineUsers = global.onlineUsers || onlineUsers || {};
global.sendNotification = sendNotification;
registerConnection(io);

// =====================================================
// ðŸ“¡ ROUTES (Modularized)
// =====================================================

// ðŸ” AUTH & PROFILE
app.use('/api/auth', require('./routes/auth'));

app.use('/api', require('./routes/profile'));

// ðŸ‘¤ USERS & NOTIFICATIONS
app.use('/api/users', require('./routes/users'));
app.use('/api/notifications', require('./routes/notifications'));

// âš™ï¸ SETTINGS & ACCOUNT
app.use('/api/settings', require('./routes/settings'));
app.use('/api/account', require('./routes/account'));

// ðŸ“ MICROBUZZ
app.use('/api/microbuzz', require('./routes/microbuzz'));

// ðŸ POSTS / LETSBUZZ
app.use('/api/posts', require('./routes/posts'));

// ðŸ  FEED & UPLOADS
app.use('/api/feed', require('./routes/feed'));
app.use('/api', require('./routes/upload'));

// ðŸ“¸ STORIES & PUBLIC PROFILES
app.use('/api/stories', require('./routes/stories'));
app.use('/api/users', require('./routes/publicProfile'));

// ðŸ” DISCOVER
app.use('/api/discover', require('./routes/discover'));

// ðŸ’¬ MESSAGES, MATCHES, SAFETY
app.use('/api/messages', require('./routes/messages'));
app.use('/api', require('./routes/likesMatches'));
app.use('/api', require('./routes/safety'));

// ðŸ§  AI WINGMAN & PREMIUM
app.use('/api', require('./routes/aiWingman'));
app.use('/api', require('./routes/premium'));

// 💘 CUPID SUPPORT
app.use('/api/cupid-support', require('./routes/cupidSupport'));

// ðŸ’¬ CHAT ROOMS
app.use('/api', require('./routes/chatRooms'));

// 📍 MEET IN THE MIDDLE — NEW CLEAN MONGODB VERSION
app.use('/api/meet-middle', require('./routes/meetMiddle'));

// 🎥 1-to-1 VIDEO CALLS
app.use('/api/video-calls', require('./routes/videoCalls'));

// 🎥🎁 VIDEO CALL BUZZCOIN GIFTS + REQUESTS
app.use('/api/video-call-gifts', require('./routes/videoCallGifts'));

// ðŸ§© DEBUG ROUTES
app.use('/api', require('./routes/debug'));

// ðŸ§© ENHANCED LETSBUZZ POSTS SYSTEM
app.use('/api', require('./routes/buzzPosts'));

// 🎁 MODULAR GIFTS + BUZZCOIN SYSTEM
app.use('/api/gifts', require('./routes/gifts'));

// ðŸ’« BUZZ STREAKS
app.use('/api', require('./routes/streak'));
logSuccess('âœ… BuzzStreak routes initialized (match & daily check-in)');
// =======================
// ðŸ’“ HEALTH CHECK (modularized)
// =======================
app.use("/api", require("./modules/health"));

// =====================================================
// ðŸ¤– BACKGROUND MODULES
// =====================================================
const { startAiWingmanTask } = require('./modules/aiWingmanTask');
startAiWingmanTask();

// ðŸ’ž Legacy Meet-in-Middle Sockets
// Optional only. The new mobile Meet in the Middle feature uses meetMiddle:* below.
try {
  const { registerMeetSockets } = require('./sockets/meetSocket');
  registerMeetSockets(io);
} catch (err) {
  console.warn('⚠️ Legacy meetSocket skipped:', err?.message || err);
}

// 📍 Meet in the Middle — NEW CLEAN SOCKETS
// Uses meetMiddle:* events only, so it does not conflict with old meet:* events.
const { registerMeetMiddleSockets } = require('./sockets/meetMiddleSocket');
registerMeetMiddleSockets(io);

// ðŸ§¾ System Startup Summary
const { logStartupSummary } = require('./modules/system');
logStartupSummary({ PORT, FEATURE_TOGGLES });

// =======================
// ðŸ›¡ï¸ GLOBAL ERROR HANDLER
// =======================
const { errorHandler } = require("./modules/errorHandler");
app.use(errorHandler);

// =====================================================
// ðŸ START SERVER
// =====================================================
(async () => {
  await initMongo();  // â­ Ensure Mongo is ready
  server.listen(PORT, () => {
    logSuccess(`ðŸƒ Mongo ready â€” Rombuzz API running on port ${PORT}`);
  });
})();

