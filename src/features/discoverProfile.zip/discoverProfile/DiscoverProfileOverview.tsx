/**
 * Path: src/features/discoverProfile/DiscoverProfileOverview.tsx
 * Purpose: About, voice intro, basics, and travel sections for Discover Profile.
 * Used by: DiscoverProfileScreen.tsx only.
 */

import { lookingForLabelFromValue } from "@/src/constants/lookingFor";
import { relationshipStyleLabelFromValue } from "@/src/constants/relationshipStyles";
import { useRomBuzzTheme } from "@/src/design/RomBuzzThemeProvider";
import { RBZFont } from "@/src/design/rombuzzTypography";
import { Ionicons } from "@expo/vector-icons";
import React from "react";
import {
    Pressable,
    StyleSheet,
    Text,
} from "react-native";

import {
    DiscoverProfileChipField,
    DiscoverProfileInfoRow,
    DiscoverProfileSection,
} from "./DiscoverProfileFields";

import {
    discoverText,
    showDiscoverField,
} from "./discoverProfilePrivacy";

export default function DiscoverProfileOverview({
  user,
  voiceUrl,
  playing,
  onToggleVoice,
}: {
  user: any;
  voiceUrl: string;
  playing: boolean;
  onToggleVoice: () => void;
}) {
  const { colors } =
    useRomBuzzTheme();

  return (
    <>
      {(!!user?.bio ||
        !!voiceUrl) && (
        <DiscoverProfileSection title="About">
          {!!user?.bio && (
            <Text
              style={[
                styles.bio,
                {
                  color:
                    colors.textSecondary,
                },
              ]}
            >
              {user.bio}
            </Text>
          )}

          {!!voiceUrl && (
            <Pressable
              onPress={
                onToggleVoice
              }
              style={[
                styles.voice,
                {
                  backgroundColor:
                    colors.surfaceMuted,

                  borderColor:
                    colors.border,
                },
              ]}
            >
              <Ionicons
                name={
                  playing
                    ? "stop"
                    : "play"
                }
                size={16}
                color={
                  colors.brand
                }
              />

              <Text
                style={[
                  styles.voiceText,
                  {
                    color:
                      colors.text,
                  },
                ]}
              >
                {playing
                  ? "Playing voice intro"
                  : "Play voice intro"}
              </Text>
            </Pressable>
          )}
        </DiscoverProfileSection>
      )}

      <DiscoverProfileSection title="Basics">
        {showDiscoverField(
          user,
          "pronouns",
          user.pronouns
        ) && (
          <DiscoverProfileInfoRow
            label="Pronouns"
            value={discoverText(
              user.pronouns
            )}
          />
        )}

        {showDiscoverField(
          user,
          "city",
          user.city
        ) && (
          <DiscoverProfileInfoRow
            label="City"
            value={discoverText(
              user.city
            )}
          />
        )}

        {showDiscoverField(
          user,
          "country",
          user.country
        ) && (
          <DiscoverProfileInfoRow
            label="Country"
            value={discoverText(
              user.country
            )}
          />
        )}

        {showDiscoverField(
          user,
          "hometown",
          user.hometown
        ) && (
          <DiscoverProfileInfoRow
            label="Hometown"
            value={discoverText(
              user.hometown
            )}
          />
        )}

        {showDiscoverField(
          user,
          "gender",
          user.gender
        ) && (
          <DiscoverProfileInfoRow
            label="Gender"
            value={discoverText(
              user.gender
            )}
          />
        )}

        {showDiscoverField(
          user,
          "orientation",
          user.orientation
        ) && (
          <DiscoverProfileInfoRow
            label="Orientation"
            value={discoverText(
              user.orientation
            )}
          />
        )}

        {showDiscoverField(
          user,
          "lookingFor",
          user.lookingFor
        ) && (
          <DiscoverProfileInfoRow
            label="Looking for"
            value={
              lookingForLabelFromValue(
                user.lookingFor
              )
            }
          />
        )}

        {showDiscoverField(
          user,
          "relationshipStyle",
          user.relationshipStyle
        ) && (
          <DiscoverProfileInfoRow
            label="Relationship style"
            value={
              relationshipStyleLabelFromValue(
                user.relationshipStyle
              )
            }
          />
        )}

        {showDiscoverField(
          user,
          "height",
          user.height
        ) && (
          <DiscoverProfileInfoRow
            label="Height"
            value={discoverText(
              user.height
            )}
          />
        )}
      </DiscoverProfileSection>

      {showDiscoverField(
        user,
        "travelVibes",
        user.travelVibes
      ) && (
        <DiscoverProfileSection title="Travel vibe">
          <DiscoverProfileChipField
            label="Travel style"
            values={
              user.travelVibes
            }
          />
        </DiscoverProfileSection>
      )}
    </>
  );
}

const styles =
  StyleSheet.create({
    bio: {
      paddingVertical: 11,
      fontFamily:
        RBZFont.regular,
      fontSize: 14,
      lineHeight: 21,
    },

    voice: {
      alignSelf:
        "flex-start",

      marginBottom: 12,

      paddingHorizontal: 12,
      paddingVertical: 8,

      borderRadius: 999,

      borderWidth:
        StyleSheet.hairlineWidth,

      flexDirection: "row",
      alignItems: "center",

      gap: 7,
    },

    voiceText: {
      fontFamily:
        RBZFont.semiBold,

      fontSize: 12.5,
    },
  });