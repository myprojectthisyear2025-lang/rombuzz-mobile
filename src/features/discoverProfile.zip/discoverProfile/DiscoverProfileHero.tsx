/**
 * Path: src/features/discoverProfile/DiscoverProfileHero.tsx
 * Purpose: Compact clickable Discover Profile hero with identity overlaid on the photo.
 * Used by: DiscoverProfileScreen.tsx only.
 */

import { useRomBuzzTheme } from "@/src/design/RomBuzzThemeProvider";
import { RBZFont } from "@/src/design/rombuzzTypography";
import { Ionicons } from "@expo/vector-icons";
import React from "react";
import {
  Image,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";

export default function DiscoverProfileHero({
  imageUri,
  displayName,
  age,
  city,
  distanceText,
  online,
  onPressPhoto,
}: {
  imageUri?: string;
  displayName: string;
  age: number | null;
  city?: string;
  distanceText?: string;
  online?: boolean;
  onPressPhoto: () => void;
}) {
  const { colors } = useRomBuzzTheme();

  const identity =
    age == null
      ? displayName
      : `${displayName}, ${age}`;

  const place = [city, distanceText]
    .filter(Boolean)
    .join(" • ");

  return (
    <Pressable
      onPress={onPressPhoto}
      disabled={!imageUri}
      style={[
        styles.hero,
        {
          backgroundColor: colors.surfaceMuted,
        },
      ]}
    >
      {imageUri ? (
        <Image
          source={{ uri: imageUri }}
          style={styles.image}
          resizeMode="cover"
        />
      ) : (
        <View style={styles.placeholder}>
          <Ionicons
            name="person-outline"
            size={54}
            color={colors.iconMuted}
          />
        </View>
      )}

      <View style={styles.bottomShade} />

      <View style={styles.statusWrap}>
        <View style={styles.statusPill}>
          <View
            style={[
              styles.statusDot,
              {
                backgroundColor: online
                  ? "#35D07F"
                  : "rgba(255,255,255,0.55)",
              },
            ]}
          />

          <Text style={styles.statusText}>
            {online ? "Online" : "Offline"}
          </Text>
        </View>
      </View>

      <View style={styles.identityWrap}>
        <Text
          style={styles.name}
          numberOfLines={1}
        >
          {identity}
        </Text>

        {!!place && (
          <View style={styles.metaRow}>
            <Ionicons
              name="location-outline"
              size={14}
              color="rgba(255,255,255,0.88)"
            />

            <Text
              style={styles.metaText}
              numberOfLines={1}
            >
              {place}
            </Text>
          </View>
        )}
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  hero: {
    marginHorizontal: 12,
    marginTop: 6,
    borderRadius: 22,
    overflow: "hidden",
    aspectRatio: 1.08,
  },

  image: {
    width: "100%",
    height: "100%",
  },

  placeholder: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },

  bottomShade: {
    position: "absolute",
    left: 0,
    right: 0,
    bottom: 0,
    height: "42%",
    backgroundColor: "rgba(0,0,0,0.38)",
  },

  statusWrap: {
    position: "absolute",
    top: 12,
    right: 12,
  },

  statusPill: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
    backgroundColor: "rgba(16,16,18,0.58)",
  },

  statusDot: {
    width: 7,
    height: 7,
    borderRadius: 4,
  },

  statusText: {
    color: "#fff",
    fontFamily: RBZFont.semiBold,
    fontSize: 11.5,
  },

  identityWrap: {
    position: "absolute",
    left: 16,
    right: 16,
    bottom: 16,
  },

  name: {
    color: "#fff",
    fontFamily: RBZFont.extraBold,
    fontSize: 28,
    lineHeight: 34,
  },

  metaRow: {
    marginTop: 4,
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
  },

  metaText: {
    flexShrink: 1,
    color: "rgba(255,255,255,0.88)",
    fontFamily: RBZFont.medium,
    fontSize: 12.5,
  },
});