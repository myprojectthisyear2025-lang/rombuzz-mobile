/**
 * Path: src/features/discoverProfile/DiscoverProfileScreen.tsx
 * Purpose: Standalone modern Discover Profile composition; no View Profile component coupling.
 * Used by: app/(tabs)/discover-profile.tsx only.
 */

import { useRomBuzzTheme } from "@/src/design/RomBuzzThemeProvider";
import { RBZFont } from "@/src/design/rombuzzTypography";
import { Ionicons } from "@expo/vector-icons";
import React, { useMemo, useState } from "react";
import {
  ActivityIndicator,
  Pressable,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  View,
  useWindowDimensions,
} from "react-native";
import { GestureDetector, GestureHandlerRootView } from "react-native-gesture-handler";
import Animated from "react-native-reanimated";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import DiscoverProfileActionDock from "./DiscoverProfileActionDock";
import DiscoverProfileDetails from "./DiscoverProfileDetails";
import DiscoverProfileGallery from "./DiscoverProfileGallery";
import DiscoverProfileHero from "./DiscoverProfileHero";
import DiscoverProfileOverview from "./DiscoverProfileOverview";
import DiscoverProfilePhotoViewer from "./DiscoverProfilePhotoViewer";
import type { DiscoverProfilePreview } from "./discoverProfileApi";
import { getDiscoverAge, getDiscoverDisplayName, getDiscoverDistanceText, getDiscoverPhotos, getDiscoverViewerPhotos, normalizeDiscoverImageUrl } from "./discoverProfileMedia";
import { useDiscoverProfileController } from "./useDiscoverProfileController";
import { useDiscoverProfileSwipe } from "./useDiscoverProfileSwipe";
import { useDiscoverVoiceIntro } from "./useDiscoverVoiceIntro";

export default function DiscoverProfileScreen({
  userId,
  returnTo,
  previewUser,
}: {
  userId: string;
  returnTo: string;
  previewUser: DiscoverProfilePreview;
}) {
  const { colors } = useRomBuzzTheme();
  const insets = useSafeAreaInsets();
  const { width } = useWindowDimensions();
  const [viewerOpen, setViewerOpen] = useState(false);
  const [viewerIndex, setViewerIndex] = useState(0);

  const controller = useDiscoverProfileController({ userId, returnTo, previewUser });
  const { user } = controller;
  const { voiceUrl, playing, toggleVoice } = useDiscoverVoiceIntro(user);

  const age = useMemo(() => getDiscoverAge(user?.dob), [user?.dob]);
  const displayName = useMemo(() => getDiscoverDisplayName(user), [user]);
  const distanceText = useMemo(() => getDiscoverDistanceText(user), [user]);
  const photos = useMemo(() => getDiscoverPhotos(user), [user]);
  const viewerPhotos = useMemo(() => getDiscoverViewerPhotos(user, photos), [photos, user]);
  const heroImage = normalizeDiscoverImageUrl(user?.avatar) || photos[0] || "";

  const openPhoto = (url: string) => {
    const index = viewerPhotos.findIndex((photo) => photo === url);
    setViewerIndex(index >= 0 ? index : 0);
    setViewerOpen(true);
  };

  const swipe = useDiscoverProfileSwipe({
    width,
    enabled: !viewerOpen && !controller.actionLoading && controller.relationshipMode !== "loading",
    onSwipeLeft: controller.secondaryAction,
    onSwipeRight: controller.primaryAction,
  });

  if (controller.loading && !user) {
    return <CenteredState color={colors.brand} background={colors.background} />;
  }

  if (!user) {
    return (
      <CenteredState
        color={colors.textMuted}
        background={colors.background}
        label="Profile unavailable"
      />
    );
  }

  return (
    <GestureHandlerRootView style={[styles.root, { backgroundColor: colors.background }]}>
      <GestureDetector gesture={swipe.gesture}>
        <Animated.View style={[styles.page, { backgroundColor: colors.background }, swipe.animatedStyle]}>
          <View style={[styles.header, { paddingTop: insets.top + 5, borderBottomColor: colors.border }]}>
            <Pressable onPress={controller.goBack} style={styles.headerButton}>
              <Ionicons name="arrow-back" size={23} color={colors.icon} />
            </Pressable>
            <Text style={[styles.headerTitle, { color: colors.text }]}>Discover</Text>
            <View style={styles.headerButton} />
          </View>

          <ScrollView
            style={styles.scroll}
            contentContainerStyle={styles.content}
            showsVerticalScrollIndicator={false}
            refreshControl={
              <RefreshControl
                refreshing={controller.refreshing}
                onRefresh={controller.refresh}
                tintColor={colors.brand}
                colors={[colors.brand]}
              />
            }
          >
            <DiscoverProfileHero
              imageUri={heroImage}
              displayName={displayName}
              age={age}
              city={user.city}
              distanceText={distanceText}
              online={!!user.isOnline}
              onPressPhoto={() => heroImage && openPhoto(heroImage)}
            />

            <DiscoverProfileOverview
              user={user}
              voiceUrl={voiceUrl}
              playing={playing}
              onToggleVoice={toggleVoice}
            />

            <DiscoverProfileDetails user={user} />

            <DiscoverProfileGallery
              photos={photos}
              onOpen={openPhoto}
            />
          </ScrollView>

          <View style={{ paddingBottom: Math.max(insets.bottom, 8) }}>
            <DiscoverProfileActionDock
              mode={controller.relationshipMode}
              firstName={user.firstName}
              loading={controller.actionLoading}
              onSkip={controller.goBack}
              onSend={controller.sendRequest}
              onDecline={() => controller.respond("reject")}
              onAccept={() => controller.respond("accept")}
              onBack={controller.goBack}
              onOpenMatched={controller.goToMatchedProfile}
            />
          </View>
        </Animated.View>
      </GestureDetector>

      <DiscoverProfilePhotoViewer
        visible={viewerOpen}
        photos={viewerPhotos}
        initialIndex={viewerIndex}
        title={displayName}
        onClose={() => setViewerOpen(false)}
        onIndexChange={setViewerIndex}
      />
    </GestureHandlerRootView>
  );
}

function CenteredState({
  color,
  background,
  label,
}: {
  color: string;
  background: string;
  label?: string;
}) {
  return (
    <View style={[styles.center, { backgroundColor: background }]}>
      {label ? (
        <Text style={[styles.stateText, { color }]}>{label}</Text>
      ) : (
        <ActivityIndicator size="large" color={color} />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  page: { flex: 1 },

  header: {
    minHeight: 56,
    paddingHorizontal: 10,
    paddingBottom: 6,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    borderBottomWidth: StyleSheet.hairlineWidth,
  },

  headerButton: {
    width: 44,
    height: 44,
    alignItems: "center",
    justifyContent: "center",
  },

  headerTitle: {
    fontFamily: RBZFont.bold,
    fontSize: 16,
  },

  scroll: { flex: 1 },
  content: { paddingBottom: 12 },

  center: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },

  stateText: {
    fontFamily: RBZFont.medium,
    fontSize: 14,
  },
});